const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');
const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

// Setup MySQL connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'music_db'
});

db.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL Database.');
});

// Setup file storage using multer
const storage = multer.diskStorage({
    destination: './public/uploads/',
    filename: (req, file, cb) => {
        cb(null, file.originalname);
    }
});
const upload = multer({ storage });

// Home route (display music and playlists)
app.get('/', (req, res) => {
    let musicQuery = 'SELECT * FROM music';
    db.query(musicQuery, (err, musicResults) => {
        if (err) throw err;
        let playlistQuery = 'SELECT * FROM playlists';
        db.query(playlistQuery, (err, playlistResults) => {
            if (err) throw err;
            res.render('index', { music: musicResults, playlists: playlistResults });
        });
    });
});

// Add new music (form and submission)
app.post('/upload', upload.single('music'), (req, res) => {
    const { title, artist } = req.body;
    const filePath = `/uploads/${req.file.originalname}`;

    const query = 'INSERT INTO music (title, artist, file_path) VALUES (?, ?, ?)';
    db.query(query, [title, artist, filePath], (err) => {
        if (err) throw err;
        res.redirect('/');
    });
});

// Create playlist
app.post('/create-playlist', (req, res) => {
    const { name, description } = req.body;

    const query = 'INSERT INTO playlists (name, description) VALUES (?, ?)';
    db.query(query, [name, description], (err) => {
        if (err) throw err;
        res.redirect('/');
    });
});

// Add music to playlist
app.post('/add-to-playlist', (req, res) => {
    const { playlist_id, music_id } = req.body;

    console.log('Received data:', req.body);  // Debugging: check what's being received

    if (!playlist_id || !music_id) {
        return res.status(400).send('Invalid playlist or music selection.');
    }

    const query = 'INSERT INTO playlist_music (playlist_id, music_id) VALUES (?, ?)';
    db.query(query, [playlist_id, music_id], (err) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Error adding music to playlist.');
        }
        res.redirect('/');
    });
});

// View playlist details
app.get('/playlist/:id', (req, res) => {
    const playlistId = req.params.id;

    // Get playlist details
    const playlistQuery = 'SELECT * FROM playlists WHERE id = ?';
    db.query(playlistQuery, [playlistId], (err, playlistResult) => {
        if (err) throw err;

        // Get all music in this playlist
        const musicQuery = `
            SELECT music.* FROM music
            JOIN playlist_music ON music.id = playlist_music.music_id
            WHERE playlist_music.playlist_id = ?
        `;
        db.query(musicQuery, [playlistId], (err, musicResults) => {
            if (err) throw err;
            res.render('playlist', { playlist: playlistResult[0], music: musicResults });
        });
    });
});

// Delete music
app.post('/delete-music/:id', (req, res) => {
    const musicId = req.params.id;

    const query = 'DELETE FROM music WHERE id = ?';
    db.query(query, [musicId], (err) => {
        if (err) throw err;
        res.redirect('/');
    });
});

// Search music
app.get('/search', (req, res) => {
    const { query } = req.query;
    const searchQuery = 'SELECT * FROM music WHERE title LIKE ?';
    db.query(searchQuery, [`%${query}%`], (err, results) => {
        if (err) throw err;
        res.render('index', { music: results });
    });
});

// Start server
app.listen(3000, () => {
    console.log('Server started on http://localhost:3000');
});